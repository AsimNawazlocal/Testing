#!/usr/bin/env python3
"""
Shield Security KSA — Static Site Generator
Generates all HTML pages for the rank-and-rent site
"""

import os, json

BASE = "/home/claude/shield-ksa"

COMPANY_NAME = "Shield Security KSA"
COMPANY_PHONE = "+966 50 000 0000"
COMPANY_EMAIL = "info@shieldsecurityksa.com"
COMPANY_ADDRESS = "King Fahad Road, Al Olaya, Riyadh 12214, Saudi Arabia"
WA_LINK = "https://wa.me/966500000000"

# ─── SHARED HEADER / FOOTER ────────────────────────────────────────────────

def header(title, desc, canonical, depth=0):
    prefix = "../" * depth
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title} | Shield Security KSA — Riyadh</title>
  <meta name="description" content="{desc}">
  <meta name="robots" content="index, follow">
  <link rel="canonical" href="https://shieldsecurityksa.com{canonical}">
  <meta property="og:title" content="{title} | Shield Security KSA">
  <meta property="og:description" content="{desc}">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://shieldsecurityksa.com{canonical}">
  <link rel="stylesheet" href="{prefix}assets/css/main.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <script type="application/ld+json">
  {{
    "@context": "https://schema.org",
    "@type": "SecurityService",
    "name": "Shield Security KSA",
    "description": "Licensed security company in Riyadh, Saudi Arabia. Ministry of Interior approved.",
    "telephone": "{COMPANY_PHONE}",
    "email": "{COMPANY_EMAIL}",
    "address": {{
      "@type": "PostalAddress",
      "addressLocality": "Riyadh",
      "addressCountry": "SA"
    }},
    "areaServed": "Saudi Arabia"
  }}
  </script>
</head>
<body>

<!-- HEADER -->
<header id="site-header">
  <div class="header-inner">
    <a href="{prefix}index.html" class="logo">
      <div class="logo-mark">S</div>
      <div class="logo-text">
        <span class="logo-name">SHIELD</span>
        <span class="logo-sub">Security KSA · Riyadh</span>
      </div>
    </a>

    <nav class="main-nav">
      <div class="nav-item">
        <a href="{prefix}manned-guarding/index.html" class="nav-link">Manned Guarding ▾</a>
        <div class="nav-dropdown">
          <a href="{prefix}manned-guarding/security-guard-services/index.html">Security Guard Services</a>
          <a href="{prefix}manned-guarding/static-security-guards/index.html">Static Security Guards</a>
          <a href="{prefix}manned-guarding/24-hour-security-guard/index.html">24-Hour Security Guard</a>
          <a href="{prefix}manned-guarding/manned-guarding-services/index.html">Manned Guarding Services</a>
          <a href="{prefix}manned-guarding/contract-security-guards/index.html">Contract Security Guards</a>
          <a href="{prefix}manned-guarding/outsourced-security-services/index.html">Outsourced Security</a>
          <a href="{prefix}manned-guarding/security-manpower-supply/index.html">Manpower Supply</a>
        </div>
      </div>
      <div class="nav-item">
        <a href="{prefix}patrol-response-monitoring/index.html" class="nav-link">Patrol & Response ▾</a>
        <div class="nav-dropdown">
          <a href="{prefix}patrol-response-monitoring/mobile-patrol-security/index.html">Mobile Patrol</a>
          <a href="{prefix}patrol-response-monitoring/vehicle-patrol-security/index.html">Vehicle Patrol</a>
          <a href="{prefix}patrol-response-monitoring/rapid-response-security/index.html">Rapid Response</a>
          <a href="{prefix}patrol-response-monitoring/alarm-monitoring-response/index.html">Alarm Monitoring</a>
          <a href="{prefix}patrol-response-monitoring/remote-cctv-monitoring/index.html">Remote CCTV</a>
        </div>
      </div>
      <div class="nav-item">
        <a href="{prefix}executive-protection/index.html" class="nav-link">Executive ▾</a>
        <div class="nav-dropdown">
          <a href="{prefix}executive-protection/executive-protection-services/index.html">Executive Protection</a>
          <a href="{prefix}executive-protection/bodyguard-services/index.html">Bodyguard Services</a>
          <a href="{prefix}executive-protection/vip-protection-services/index.html">VIP Protection</a>
          <a href="{prefix}executive-protection/armed-escort-services/index.html">Armed Escort</a>
          <a href="{prefix}executive-protection/royal-diplomatic-security/index.html">Royal & Diplomatic</a>
        </div>
      </div>
      <div class="nav-item">
        <a href="{prefix}event-security/index.html" class="nav-link">Events ▾</a>
        <div class="nav-dropdown">
          <a href="{prefix}event-security/event-security-services/index.html">Event Security</a>
          <a href="{prefix}event-security/crowd-control-security/index.html">Crowd Control</a>
          <a href="{prefix}event-security/wedding-security-services/index.html">Wedding Security</a>
          <a href="{prefix}event-security/corporate-event-security/index.html">Corporate Events</a>
          <a href="{prefix}event-security/concert-festival-security/index.html">Concerts & Festivals</a>
          <a href="{prefix}event-security/vip-event-security/index.html">VIP Events</a>
        </div>
      </div>
      <div class="nav-item">
        <a href="{prefix}industrial-security/index.html" class="nav-link">Industrial ▾</a>
        <div class="nav-dropdown">
          <a href="{prefix}industrial-security/industrial-security-services/index.html">Industrial Security</a>
          <a href="{prefix}industrial-security/factory-security-guards/index.html">Factory Security</a>
          <a href="{prefix}industrial-security/oil-gas-security-services/index.html">Oil &amp; Gas</a>
          <a href="{prefix}industrial-security/hcis-compliant-security/index.html">HCIS Compliance</a>
          <a href="{prefix}construction-mega-project-security/neom-security-services/index.html">NEOM Security</a>
        </div>
      </div>
      <div class="nav-item">
        <a href="{prefix}technology-security-systems/index.html" class="nav-link">Technology ▾</a>
        <div class="nav-dropdown">
          <a href="{prefix}technology-security-systems/cctv-monitoring-services/index.html">CCTV Monitoring</a>
          <a href="{prefix}technology-security-systems/access-control-systems/index.html">Access Control</a>
          <a href="{prefix}technology-security-systems/biometric-security-systems/index.html">Biometric Systems</a>
          <a href="{prefix}technology-security-systems/smart-security-solutions/index.html">Smart Security</a>
        </div>
      </div>
    </nav>

    <div class="header-cta">
      <a href="tel:{COMPANY_PHONE}" class="header-phone">📞 {COMPANY_PHONE}</a>
      <a href="{prefix}informational/request-security-quote/index.html" class="btn btn-gold btn-sm">Get Quote</a>
    </div>

    <div class="nav-toggle" id="nav-toggle">
      <span></span><span></span><span></span>
    </div>
  </div>
</header>

<!-- MOBILE NAV -->
<nav class="mobile-nav" id="mobile-nav">
  <details class="mobile-nav-group"><summary>Manned Guarding</summary>
    <a href="{prefix}manned-guarding/security-guard-services/index.html">Security Guard Services</a>
    <a href="{prefix}manned-guarding/static-security-guards/index.html">Static Security Guards</a>
    <a href="{prefix}manned-guarding/24-hour-security-guard/index.html">24-Hour Security Guard</a>
    <a href="{prefix}manned-guarding/contract-security-guards/index.html">Contract Security Guards</a>
    <a href="{prefix}manned-guarding/outsourced-security-services/index.html">Outsourced Security</a>
  </details>
  <details class="mobile-nav-group"><summary>Patrol & Response</summary>
    <a href="{prefix}patrol-response-monitoring/mobile-patrol-security/index.html">Mobile Patrol</a>
    <a href="{prefix}patrol-response-monitoring/rapid-response-security/index.html">Rapid Response</a>
    <a href="{prefix}patrol-response-monitoring/alarm-monitoring-response/index.html">Alarm Monitoring</a>
    <a href="{prefix}patrol-response-monitoring/remote-cctv-monitoring/index.html">Remote CCTV</a>
  </details>
  <details class="mobile-nav-group"><summary>Executive Protection</summary>
    <a href="{prefix}executive-protection/bodyguard-services/index.html">Bodyguard Services</a>
    <a href="{prefix}executive-protection/vip-protection-services/index.html">VIP Protection</a>
    <a href="{prefix}executive-protection/royal-diplomatic-security/index.html">Royal & Diplomatic</a>
  </details>
  <details class="mobile-nav-group"><summary>Events</summary>
    <a href="{prefix}event-security/event-security-services/index.html">Event Security</a>
    <a href="{prefix}event-security/crowd-control-security/index.html">Crowd Control</a>
    <a href="{prefix}event-security/wedding-security-services/index.html">Wedding Security</a>
  </details>
  <details class="mobile-nav-group"><summary>Industrial</summary>
    <a href="{prefix}industrial-security/oil-gas-security-services/index.html">Oil & Gas</a>
    <a href="{prefix}industrial-security/hcis-compliant-security/index.html">HCIS Compliance</a>
    <a href="{prefix}construction-mega-project-security/neom-security-services/index.html">NEOM</a>
  </details>
  <details class="mobile-nav-group"><summary>Technology</summary>
    <a href="{prefix}technology-security-systems/cctv-monitoring-services/index.html">CCTV</a>
    <a href="{prefix}technology-security-systems/access-control-systems/index.html">Access Control</a>
    <a href="{prefix}technology-security-systems/smart-security-solutions/index.html">Smart Security</a>
  </details>
  <div style="padding:1rem 0">
    <a href="{prefix}informational/request-security-quote/index.html" class="btn btn-gold" style="width:100%;justify-content:center">Get Free Quote</a>
  </div>
</nav>
"""

def footer(prefix=""):
    return f"""
<!-- FOOTER -->
<footer>
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <a href="{prefix}index.html" class="logo">
          <div class="logo-mark">S</div>
          <div class="logo-text">
            <span class="logo-name">SHIELD</span>
            <span class="logo-sub">Security KSA · Riyadh</span>
          </div>
        </a>
        <p>Ministry of Interior licensed security company serving Riyadh and all of Saudi Arabia. Trusted by 500+ clients across all sectors.</p>
        <div class="footer-socials">
          <a href="#" class="social-btn" aria-label="LinkedIn">in</a>
          <a href="#" class="social-btn" aria-label="Twitter">𝕏</a>
          <a href="{WA_LINK}" class="social-btn" aria-label="WhatsApp">W</a>
        </div>
      </div>

      <div class="footer-col">
        <h5>Key Services</h5>
        <ul>
          <li><a href="{prefix}manned-guarding/security-guard-services/index.html">Security Guard Services</a></li>
          <li><a href="{prefix}executive-protection/bodyguard-services/index.html">Bodyguard Services</a></li>
          <li><a href="{prefix}event-security/event-security-services/index.html">Event Security</a></li>
          <li><a href="{prefix}industrial-security/oil-gas-security-services/index.html">Oil & Gas Security</a></li>
          <li><a href="{prefix}patrol-response-monitoring/mobile-patrol-security/index.html">Mobile Patrol</a></li>
          <li><a href="{prefix}cash-in-transit-security/cash-in-transit-cit-services/index.html">Cash-in-Transit</a></li>
          <li><a href="{prefix}technology-security-systems/cctv-monitoring-services/index.html">CCTV Monitoring</a></li>
          <li><a href="{prefix}female-security-guards/female-security-guard-services/index.html">Female Security Guards</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h5>Sectors</h5>
        <ul>
          <li><a href="{prefix}commercial-corporate-security/commercial-security-services/index.html">Commercial</a></li>
          <li><a href="{prefix}residential-security/residential-security-guards/index.html">Residential</a></li>
          <li><a href="{prefix}banking-financial-security/bank-security-guards/index.html">Banking</a></li>
          <li><a href="{prefix}healthcare-security/hospital-security-guards/index.html">Healthcare</a></li>
          <li><a href="{prefix}education-security/school-security-guards/index.html">Education</a></li>
          <li><a href="{prefix}hospitality-tourism-security/hotel-security-guards/index.html">Hotels</a></li>
          <li><a href="{prefix}construction-mega-project-security/neom-security-services/index.html">NEOM / Giga Projects</a></li>
          <li><a href="{prefix}diplomatic-government-security/embassy-consulate-security/index.html">Embassies</a></li>
        </ul>
      </div>

      <div class="footer-col">
        <h5>Contact</h5>
        <ul>
          <li><a href="tel:{COMPANY_PHONE}">{COMPANY_PHONE}</a></li>
          <li><a href="mailto:{COMPANY_EMAIL}">{COMPANY_EMAIL}</a></li>
          <li><a href="{WA_LINK}">WhatsApp Us</a></li>
          <li><a href="{prefix}informational/request-security-quote/index.html">Request a Quote</a></li>
          <li><a href="{prefix}informational/security-guard-jobs-ksa/index.html">Jobs / Careers</a></li>
        </ul>
        <div class="mt-3">
          <span class="badge badge-green">● Available 24/7</span>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <p>© 2025 Shield Security KSA. Ministry of Interior License No. XXXX/2024. All rights reserved.</p>
      <div class="footer-bottom-links">
        <a href="#">Privacy Policy</a>
        <a href="#">Terms of Service</a>
        <a href="{prefix}informational/request-security-quote/index.html">Get Quote</a>
      </div>
    </div>
  </div>
</footer>

<!-- WhatsApp Float -->
<a href="{WA_LINK}" class="whatsapp-float" target="_blank" rel="noopener" aria-label="Chat on WhatsApp">💬</a>

<script src="{prefix}assets/js/main.js"></script>
</body>
</html>"""

# ─── CTA SECTION ───────────────────────────────────────────────────────────────
def cta_section(prefix=""):
    return f"""
<section class="section">
  <div class="container">
    <div class="cta-banner fade-up">
      <h2>Ready to Secure Your Property?</h2>
      <p>Get a free, no-obligation security assessment from our licensed team. We respond within 2 hours.</p>
      <div class="cta-actions">
        <a href="{prefix}informational/request-security-quote/index.html" class="btn btn-gold btn-lg">Get Free Quote</a>
        <a href="tel:{COMPANY_PHONE}" class="btn btn-ghost btn-lg">📞 Call Now</a>
        <a href="{WA_LINK}" class="btn btn-outline btn-lg" target="_blank">WhatsApp Us</a>
      </div>
    </div>
  </div>
</section>"""

# ─── TESTIMONIALS ─────────────────────────────────────────────────────────────
TESTIMONIALS = [
    ("A.K.", "Operations Manager, Al Rajhi Bank", "Shield Security has been protecting our branches for 3 years. Professional, punctual, and always compliant with our security protocols."),
    ("F.A.", "Facilities Director, King Abdullah Medical City", "We needed female security guards for our hospital. Shield delivered trained, professional staff within 48 hours."),
    ("M.S.", "Event Manager, Riyadh Season", "For our concert series, Shield handled crowd control flawlessly. 10,000+ attendees, zero incidents."),
]

def testimonials_block():
    cards = ""
    for init, title, text in TESTIMONIALS:
        cards += f"""
    <div class="testimonial-card fade-up">
      <div class="testimonial-stars">★★★★★</div>
      <p class="testimonial-text">"{text}"</p>
      <div class="testimonial-author">
        <div class="author-avatar">{init[0]}</div>
        <div>
          <div class="author-name">{init}</div>
          <div class="author-title">{title}</div>
        </div>
      </div>
    </div>"""
    return f"""
<section class="section section-alt">
  <div class="container">
    <div class="section-header fade-up">
      <span class="section-eyebrow">Client Testimonials</span>
      <h2 class="section-title">Trusted by Leading Organizations</h2>
      <div class="gold-divider"></div>
    </div>
    <div class="testimonials-grid">{cards}</div>
  </div>
</section>"""

# ─── FAQ BLOCK ─────────────────────────────────────────────────────────────────
def faq_block(faqs):
    items = ""
    for q, a in faqs:
        items += f"""
    <div class="faq-item">
      <button class="faq-question">{q}<span class="faq-icon">+</span></button>
      <div class="faq-answer"><p>{a}</p></div>
    </div>"""
    return f"""
<section class="section">
  <div class="container">
    <div class="section-header fade-up">
      <span class="section-eyebrow">FAQ</span>
      <h2 class="section-title">Frequently Asked Questions</h2>
      <div class="gold-divider"></div>
    </div>
    <div class="content-block fade-up">{items}</div>
  </div>
</section>"""

# ─── PAGE HERO ────────────────────────────────────────────────────────────────
def page_hero(breadcrumbs, tag, h1, desc, prefix="", badges=""):
    bc_html = ""
    for label, url in breadcrumbs:
        if url:
            bc_html += f'<a href="{prefix}{url}">{label}</a><span class="sep">›</span>'
        else:
            bc_html += f'<span>{label}</span>'
    return f"""
<section class="page-hero">
  <div class="container">
    <nav class="breadcrumb">{bc_html}</nav>
    <span class="page-hero-tag">{tag}</span>
    <h1>{h1}</h1>
    <p class="page-hero-desc">{desc}</p>
    {badges}
    <div class="hero-actions">
      <a href="{prefix}informational/request-security-quote/index.html" class="btn btn-gold btn-lg">Get Free Quote</a>
      <a href="tel:{COMPANY_PHONE}" class="btn btn-ghost btn-lg">📞 {COMPANY_PHONE}</a>
    </div>
  </div>
</section>"""

# ─── CERT BAR ─────────────────────────────────────────────────────────────────
CERT_BAR = """
<div class="cert-bar">
  <div class="container">
    <div class="cert-inner">
      <div class="cert-item">🏛️ <span>Ministry of Interior Licensed</span></div>
      <div class="cert-item">✅ <span>HCIS Compliant</span></div>
      <div class="cert-item">⭐ <span>ISO 9001:2015</span></div>
      <div class="cert-item">🛡️ <span>500+ Active Clients</span></div>
      <div class="cert-item">⏰ <span>24/7 Operations</span></div>
      <div class="cert-item">🇸🇦 <span>Saudization Compliant</span></div>
    </div>
  </div>
</div>"""

# ─── HOMEPAGE ─────────────────────────────────────────────────────────────────
def build_homepage():
    services = [
        ("🛡️", "Manned Guarding", "Professional security guards for all facilities, available 24/7 on contract basis.", "manned-guarding/index.html"),
        ("🚗", "Patrol & Response", "Mobile patrol units and rapid response teams covering all Riyadh districts.", "patrol-response-monitoring/index.html"),
        ("💼", "Executive Protection", "Close protection officers and bodyguard services for VIPs and executives.", "executive-protection/index.html"),
        ("🎪", "Event Security", "Comprehensive security management for events from 50 to 50,000 attendees.", "event-security/index.html"),
        ("🏭", "Industrial Security", "Specialized guards for oil & gas, factories, warehouses, and HCIS-regulated sites.", "industrial-security/index.html"),
        ("📹", "Technology Systems", "CCTV, access control, biometric, and smart security system installation.", "technology-security-systems/index.html"),
        ("🏠", "Residential Security", "Villa guards, gated community security, and residential compound protection.", "residential-security/index.html"),
        ("💵", "Cash-in-Transit", "Armored transport, ATM security, and secure valuables delivery services.", "cash-in-transit-security/index.html"),
        ("👩", "Female Security Guards", "Trained female security officers for malls, hospitals, and women-only venues.", "female-security-guards/index.html"),
        ("🏢", "Commercial Security", "Office, mall, and corporate campus security management solutions.", "commercial-corporate-security/index.html"),
        ("🏗️", "NEOM & Mega Projects", "Specialized security for NEOM, Qiddiya, and Saudi Vision 2030 giga-projects.", "construction-mega-project-security/index.html"),
        ("📊", "Security Consulting", "Risk assessments, audits, threat analysis, and security management consulting.", "security-consulting-risk-management/index.html"),
    ]

    cards = ""
    for icon, title, desc, url in services:
        cards += f"""
      <a href="{url}" class="service-card fade-up">
        <div class="service-icon">{icon}</div>
        <h3>{title}</h3>
        <p>{desc}</p>
        <span class="service-link">Learn More</span>
      </a>"""

    sectors = [
        ("🏦","Banking","banking-financial-security/bank-security-guards/index.html"),
        ("🏥","Healthcare","healthcare-security/hospital-security-guards/index.html"),
        ("🎓","Education","education-security/school-security-guards/index.html"),
        ("🛒","Retail","retail-security/retail-security-guards/index.html"),
        ("✈️","Airport","airport-port-maritime-security/airport-security-services/index.html"),
        ("🏨","Hotels","hospitality-tourism-security/hotel-security-guards/index.html"),
        ("🏛️","Government","diplomatic-government-security/government-facility-security/index.html"),
        ("🚢","Maritime","airport-port-maritime-security/maritime-port-security/index.html"),
    ]

    sector_pills = ""
    for icon, label, url in sectors:
        sector_pills += f"""
      <a href="{url}" class="industry-pill fade-up">
        <span class="icon">{icon}</span>
        <span>{label}</span>
      </a>"""

    content = header(
        "Security Company Riyadh Saudi Arabia",
        "Shield Security KSA — Ministry of Interior licensed security company in Riyadh. Professional security guards, patrol, executive protection, event security and technology solutions across Saudi Arabia.",
        "/",
        depth=0
    )
    content += CERT_BAR
    content += f"""
<!-- HERO -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-grid"></div>
  <div class="hero-content">
    <div class="hero-left">
      <div class="hero-eyebrow">Ministry of Interior Licensed · Riyadh, KSA</div>
      <h1>Riyadh's <span class="gold">Most Trusted</span> Security Company</h1>
      <p class="hero-desc">Shield Security KSA provides licensed, professional security services to businesses, embassies, events, and residences across Saudi Arabia. Available 24 hours, 365 days.</p>
      <div class="hero-actions">
        <a href="informational/request-security-quote/index.html" class="btn btn-gold btn-lg">Get Free Security Quote</a>
        <a href="tel:{COMPANY_PHONE}" class="btn btn-ghost btn-lg">📞 Call 24/7</a>
      </div>
      <div class="hero-stats">
        <div class="stat-item">
          <span class="stat-num" data-count="500" data-suffix="+">500+</span>
          <span class="stat-label">Active Clients</span>
        </div>
        <div class="stat-item">
          <span class="stat-num" data-count="2000" data-suffix="+">2,000+</span>
          <span class="stat-label">Trained Guards</span>
        </div>
        <div class="stat-item">
          <span class="stat-num" data-count="15" data-suffix=" Yrs">15 Yrs</span>
          <span class="stat-label">Experience</span>
        </div>
      </div>
    </div>
    <div class="hero-visual">
      <div class="hero-shield">
        <div class="shield-outer">
          <div class="shield-inner-text">SHIELD<br><span style="font-size:1.2rem;color:var(--white-soft)">SECURITY</span></div>
        </div>
        <div class="hero-badge">
          <span>24/7</span>
          <span>Always On</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section class="section" id="services">
  <div class="container">
    <div class="section-header fade-up">
      <span class="section-eyebrow">Our Services</span>
      <h2 class="section-title">Comprehensive Security Solutions</h2>
      <div class="gold-divider"></div>
      <p class="section-desc">From a single security guard to a full integrated security program — we cover every protection need in Saudi Arabia.</p>
    </div>
    <div class="services-grid">{cards}</div>
  </div>
</section>

<!-- WHY US -->
<section class="section section-alt">
  <div class="container">
    <div class="why-grid">
      <div class="fade-up">
        <span class="section-eyebrow">Why Shield Security KSA</span>
        <h2 class="section-title">Saudi Arabia's Security Standard</h2>
        <div class="gold-divider" style="margin:1rem 0"></div>
        <p>We are a Ministry of Interior (MOI) licensed security company headquartered in Riyadh, serving all regions of the Kingdom. Every guard is trained, vetted, and insured.</p>
        <div class="mt-4">
          <a href="informational/best-security-company-saudi-arabia/index.html" class="btn btn-outline">Why We're #1 in KSA</a>
        </div>
      </div>
      <div class="fade-up">
        <ul class="why-list">
          <li>
            <div class="why-check">✓</div>
            <div>
              <strong>Ministry of Interior Licensed</strong>
              <p>Fully compliant with Saudi security regulations. License number available on request.</p>
            </div>
          </li>
          <li>
            <div class="why-check">✓</div>
            <div>
              <strong>Saudization (Nitaqat) Compliant</strong>
              <p>We maintain required Saudi national employment ratios across all contracts.</p>
            </div>
          </li>
          <li>
            <div class="why-check">✓</div>
            <div>
              <strong>HCIS Certified for Critical Infrastructure</strong>
              <p>Approved to guard oil, gas, energy, and high-criticality installations.</p>
            </div>
          </li>
          <li>
            <div class="why-check">✓</div>
            <div>
              <strong>ISO 9001:2015 Quality Management</strong>
              <p>Standardized processes ensuring consistent, high-quality service delivery.</p>
            </div>
          </li>
          <li>
            <div class="why-check">✓</div>
            <div>
              <strong>2-Hour Emergency Response</strong>
              <p>Rapid deployment capability across Riyadh, Jeddah, Dammam, and major KSA cities.</p>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- SECTORS -->
<section class="section">
  <div class="container">
    <div class="section-header fade-up">
      <span class="section-eyebrow">Industries We Serve</span>
      <h2 class="section-title">Security Across Every Sector</h2>
      <div class="gold-divider"></div>
    </div>
    <div class="industries-grid">{sector_pills}</div>
  </div>
</section>

<!-- PROCESS -->
<section class="section section-alt">
  <div class="container">
    <div class="section-header fade-up">
      <span class="section-eyebrow">How It Works</span>
      <h2 class="section-title">Start in 4 Simple Steps</h2>
      <div class="gold-divider"></div>
    </div>
    <div class="process-steps">
      <div class="process-step fade-up">
        <div class="step-num">01</div>
        <h4>Contact Us</h4>
        <p>Call, WhatsApp, or fill out our quote form. We respond within 2 hours.</p>
      </div>
      <div class="process-step fade-up">
        <div class="step-num">02</div>
        <h4>Free Assessment</h4>
        <p>Our security consultants visit your site and assess your requirements.</p>
      </div>
      <div class="process-step fade-up">
        <div class="step-num">03</div>
        <h4>Custom Proposal</h4>
        <p>We provide a tailored security plan and transparent pricing.</p>
      </div>
      <div class="process-step fade-up">
        <div class="step-num">04</div>
        <h4>Deploy & Protect</h4>
        <p>Guards are deployed within 48 hours of contract signing.</p>
      </div>
    </div>
  </div>
</section>
"""
    content += testimonials_block()
    content += cta_section()
    content += footer()
    return content

# ─── PARENT PAGE BUILDER ──────────────────────────────────────────────────────
def build_parent_page(slug, title, desc, tag, icon, children, faqs=None, prefix=""):
    depth = 1
    p = "../"

    child_cards = ""
    for child_slug, child_title, child_desc, child_icon in children:
        child_cards += f"""
      <a href="{child_slug}/index.html" class="service-card fade-up">
        <div class="service-icon">{child_icon}</div>
        <h3>{child_title}</h3>
        <p>{child_desc}</p>
        <span class="service-link">Learn More</span>
      </a>"""

    breadcrumbs = [("Home", "index.html"), (title, None)]
    badges = '<span class="badge badge-gold">MOI Licensed</span>&nbsp;<span class="badge badge-green">24/7 Service</span>'

    content = header(title, desc, f"/{slug}/", depth=depth)
    content += CERT_BAR
    content += page_hero(breadcrumbs, tag, title, desc, prefix=p, badges=badges)
    content += f"""
<section class="section">
  <div class="container">
    <div class="section-header fade-up">
      <span class="section-eyebrow">Services</span>
      <h2 class="section-title">Our {title} Services</h2>
      <div class="gold-divider"></div>
    </div>
    <div class="services-grid">{child_cards}</div>
  </div>
</section>"""

    content += testimonials_block()
    if faqs:
        content += faq_block(faqs)
    content += cta_section(prefix=p)
    content += footer(prefix=p)
    return content


# ─── LEAF PAGE BUILDER ────────────────────────────────────────────────────────
def build_leaf_page(parent_slug, parent_title, slug, title, desc, tag, icon, content_sections, faqs=None, related=None):
    depth = 2
    p = "../../"
    breadcrumbs = [
        ("Home", "index.html"),
        (parent_title, f"{parent_slug}/index.html"),
        (title, None)
    ]
    badges = '<span class="badge badge-gold">MOI Licensed</span>&nbsp;<span class="badge badge-green">24/7 Available</span>'

    html = header(title, desc, f"/{parent_slug}/{slug}/", depth=depth)
    html += CERT_BAR
    html += page_hero(breadcrumbs, tag, title, desc, prefix=p, badges=badges)

    html += '<section class="section"><div class="container"><div class="two-col-content">'
    html += '<div class="main-content">'

    for section_title, section_body in content_sections:
        html += f'<div class="content-block fade-up"><h2>{section_title}</h2>{section_body}</div>'

    html += '</div>'  # end main-content

    # Sidebar
    sidebar_links = ""
    if related:
        for r_title, r_url in related:
            sidebar_links += f'<li><a href="{p}{r_url}">{r_title}</a></li>'

    html += f"""
<div class="sidebar">
  <div class="sidebar-card fade-up">
    <h4>Get a Free Quote</h4>
    <p style="font-size:.85rem;color:var(--gray-light);margin-bottom:1.25rem">Contact us now for a free site assessment and security proposal.</p>
    <a href="{p}informational/request-security-quote/index.html" class="btn btn-gold" style="width:100%;justify-content:center">Request Quote</a>
    <div class="mt-2">
      <a href="tel:{COMPANY_PHONE}" class="btn btn-ghost btn-sm" style="width:100%;justify-content:center">📞 {COMPANY_PHONE}</a>
    </div>
  </div>
  <div class="sidebar-card fade-up">
    <h4>Related Services</h4>
    <ul class="sidebar-links">
      {sidebar_links}
    </ul>
  </div>
  <div class="sidebar-card fade-up">
    <h4>Certifications</h4>
    <ul class="sidebar-links">
      <li><a href="#">Ministry of Interior Licensed</a></li>
      <li><a href="#">HCIS Compliant</a></li>
      <li><a href="#">ISO 9001:2015</a></li>
      <li><a href="#">Saudization Compliant</a></li>
    </ul>
  </div>
</div>
"""
    html += '</div></div></section>'  # end two-col-content, container, section

    if faqs:
        html += faq_block(faqs)

    html += testimonials_block()
    html += cta_section(prefix=p)
    html += footer(prefix=p)
    return html


# ─── PAGE DEFINITIONS ─────────────────────────────────────────────────────────

# MANNED GUARDING

MG_CHILDREN = [
    ("security-guard-services", "Security Guard Services", "Uniformed security guards for all property types in Riyadh and KSA.", "🛡️"),
    ("static-security-guards", "Static Security Guards", "Fixed-post guards for access control, reception, and perimeter security.", "🚧"),
    ("24-hour-security-guard", "24-Hour Security Guard", "Round-the-clock guard coverage with shift rotations and supervisor oversight.", "⏰"),
    ("manned-guarding-services", "Manned Guarding Services", "Comprehensive manned security programs tailored to your specific needs.", "👮"),
    ("contract-security-guards", "Contract Security Guards", "Short and long-term security contracts with flexible staffing options.", "📋"),
    ("outsourced-security-services", "Outsourced Security Services", "Full security department outsourcing, saving HR and admin overhead.", "🤝"),
    ("security-manpower-supply", "Security Manpower Supply", "Bulk supply of trained security personnel for large-scale operations.", "👥"),
]

MG_FAQS = [
    ("What qualifications do your security guards have?", "All our guards hold current Saudi Ministry of Interior licenses. They receive training in first aid, emergency response, access control, customer service, and are background-checked before deployment."),
    ("Can you provide guards on short notice?", "Yes. For standard deployments we can have guards on-site within 48 hours. For emergency situations, we offer rapid deployment within 4-8 hours subject to availability."),
    ("Do you provide armed security guards?", "Yes, we provide licensed armed security guards for high-risk environments. Armed deployment requires additional approvals under Saudi law, which we handle on your behalf."),
    ("What is your pricing model?", "We charge on a per-guard, per-shift basis or monthly contract rate. Pricing depends on the security level required, hours, and location. Contact us for a custom quote."),
]

MG_LEAF_PAGES = {
    "security-guard-services": {
        "title": "Security Guard Services in Riyadh",
        "desc": "Professional security guard services in Riyadh, Saudi Arabia. MOI licensed guards for commercial, residential, and industrial properties.",
        "tag": "Manned Guarding · Riyadh, KSA",
        "icon": "🛡️",
        "sections": [
            ("Professional Security Guard Services in Riyadh", """
<p>Shield Security KSA provides licensed security guard services across Riyadh and all regions of Saudi Arabia. Our guards are trained to the highest standards and operate under strict Ministry of Interior regulations.</p>
<p>Whether you need a single guard for a retail store or a full security team for a corporate campus, we design and deliver tailored solutions.</p>"""),
            ("What Our Security Guard Services Include", """<ul>
<li>24/7 uniformed security guard deployment</li>
<li>Access control and visitor management</li>
<li>Perimeter patrol and monitoring</li>
<li>Incident response and reporting</li>
<li>Emergency evacuation assistance</li>
<li>Coordination with police and emergency services</li>
<li>CCTV and alarm system monitoring</li>
<li>Shift supervisors and site managers</li>
</ul>"""),
            ("Industries We Serve", """<p>Our security guards serve clients across every major sector in Saudi Arabia:</p>
<ul>
<li>Commercial offices and business parks</li>
<li>Retail malls and shopping centers</li>
<li>Residential compounds and villas</li>
<li>Industrial facilities and warehouses</li>
<li>Hospitals and healthcare facilities</li>
<li>Schools, universities, and campuses</li>
<li>Hotels, resorts, and hospitality venues</li>
<li>Government and embassy compounds</li>
</ul>"""),
        ],
        "faqs": [
            ("Are your security guards licensed in Saudi Arabia?", "Yes. All Shield Security KSA guards hold valid Ministry of Interior security licenses and undergo regular re-certification."),
            ("Can I request specific guards for my site?", "Yes. For long-term contracts, we assign dedicated guards to your site to maintain consistency and site-specific knowledge."),
            ("Do you provide guards who speak English?", "Yes. We have English, Arabic, and multilingual guards available, particularly suited for international businesses and embassies."),
        ],
        "related": [
            ("Static Security Guards", "manned-guarding/static-security-guards/index.html"),
            ("24-Hour Security", "manned-guarding/24-hour-security-guard/index.html"),
            ("Contract Security Guards", "manned-guarding/contract-security-guards/index.html"),
            ("Mobile Patrol", "patrol-response-monitoring/mobile-patrol-security/index.html"),
        ]
    },
    "static-security-guards": {
        "title": "Static Security Guards Riyadh",
        "desc": "Fixed-post static security guards for access control, gatehouse, reception, and perimeter posts across Saudi Arabia.",
        "tag": "Static Guarding · Riyadh, KSA",
        "icon": "🚧",
        "sections": [
            ("Static Security Guard Services", "<p>Static security guards are permanently assigned to a fixed post — entrance gates, reception lobbies, parking areas, or server rooms. They are the first line of defense for your facility.</p><p>Our static guards are trained in access control procedures, visitor management, emergency response, and professional communication — essential for facilities with high public or staff footfall.</p>"),
            ("Static Guard Post Types", "<ul><li>Main entrance and gate control</li><li>Reception and lobby security</li><li>Loading bay and warehouse access</li><li>Car park and perimeter posts</li><li>Control room operators</li><li>Internal security checkpoints</li><li>Server room and data center guards</li></ul>"),
        ],
        "faqs": [
            ("What is the difference between static and mobile guards?", "Static guards are assigned to a fixed location and focus on that area's security. Mobile guards patrol multiple locations and respond to incidents across a wider area."),
            ("Can static guards be armed?", "Yes, where required and legally permitted, we can provide armed static guards at high-value or high-risk fixed posts."),
        ],
        "related": [
            ("Security Guard Services", "manned-guarding/security-guard-services/index.html"),
            ("24-Hour Security Guard", "manned-guarding/24-hour-security-guard/index.html"),
            ("Access Control Systems", "technology-security-systems/access-control-systems/index.html"),
        ]
    },
    "24-hour-security-guard": {
        "title": "24-Hour Security Guard Services Riyadh",
        "desc": "Round-the-clock 24-hour security guard coverage in Riyadh. Day and night shifts, supervisor oversight, and incident reporting.",
        "tag": "24/7 Guarding · Riyadh, KSA",
        "icon": "⏰",
        "sections": [
            ("24/7 Security Guard Coverage", "<p>We provide uninterrupted 24-hour security guard coverage with properly managed shift rotations. No gaps in coverage, no lone-worker risks, and full supervisory oversight around the clock.</p>"),
            ("Shift Structure", "<ul><li>Day shift: 06:00 – 18:00</li><li>Night shift: 18:00 – 06:00</li><li>Rotating shift supervisors</li><li>Real-time incident reporting</li><li>Morning briefings and handovers</li><li>Regular welfare checks on guards</li></ul>"),
        ],
        "faqs": [
            ("How do you ensure guard alertness overnight?", "We conduct random supervisor checks, require hourly activity logs, and use real-time monitoring technology to ensure guards remain alert at all times."),
        ],
        "related": [
            ("Static Security Guards", "manned-guarding/static-security-guards/index.html"),
            ("Mobile Patrol", "patrol-response-monitoring/mobile-patrol-security/index.html"),
            ("Remote CCTV Monitoring", "patrol-response-monitoring/remote-cctv-monitoring/index.html"),
        ]
    },
    "manned-guarding-services": {
        "title": "Manned Guarding Services Saudi Arabia",
        "desc": "Comprehensive manned guarding services across Saudi Arabia. Tailored guard programs for commercial, industrial, and residential clients.",
        "tag": "Manned Guarding · Saudi Arabia",
        "icon": "👮",
        "sections": [
            ("Comprehensive Manned Guarding", "<p>Our manned guarding services go beyond deploying guards. We design a full security program: shift patterns, post orders, escalation procedures, reporting formats, and supervisor structures — all customized to your site.</p>"),
            ("Program Components", "<ul><li>Site security assessment</li><li>Guard deployment plan</li><li>Written post orders and SOPs</li><li>Uniform and equipment provision</li><li>Guard training and induction</li><li>Supervisor and manager allocation</li><li>Monthly performance reviews</li><li>Incident and audit reporting</li></ul>"),
        ],
        "faqs": [
            ("Do you handle all HR aspects of the guards?", "Yes. We manage all payroll, uniforms, insurance, training, and compliance. You simply pay a monthly service fee."),
        ],
        "related": [
            ("Security Guard Services", "manned-guarding/security-guard-services/index.html"),
            ("Outsourced Security", "manned-guarding/outsourced-security-services/index.html"),
            ("Security Consulting", "security-consulting-risk-management/security-consulting-services/index.html"),
        ]
    },
    "contract-security-guards": {
        "title": "Contract Security Guards Riyadh Saudi Arabia",
        "desc": "Flexible short and long-term security guard contracts in Riyadh. Monthly, quarterly, and annual contracts available.",
        "tag": "Contract Guarding · Riyadh, KSA",
        "icon": "📋",
        "sections": [
            ("Flexible Security Guard Contracts", "<p>We offer security guard contracts on monthly, quarterly, and annual terms. Long-term contracts benefit from reduced rates and dedicated account management.</p>"),
            ("Contract Options", "<ul><li>Monthly rolling contracts</li><li>Annual fixed-term contracts</li><li>Project-based contracts (construction, events)</li><li>Emergency short-term deployments</li><li>Seasonal staffing increases</li></ul>"),
        ],
        "faqs": [
            ("What is the minimum contract duration?", "Our minimum contract is 1 month. For project security, we also offer weekly arrangements during mobilization phases."),
        ],
        "related": [
            ("Security Manpower Supply", "manned-guarding/security-manpower-supply/index.html"),
            ("Outsourced Security", "manned-guarding/outsourced-security-services/index.html"),
        ]
    },
    "outsourced-security-services": {
        "title": "Outsourced Security Services Saudi Arabia",
        "desc": "Complete security department outsourcing in Saudi Arabia. We handle all guards, managers, HR, compliance, and reporting.",
        "tag": "Security Outsourcing · KSA",
        "icon": "🤝",
        "sections": [
            ("Total Security Outsourcing", "<p>Replace your in-house security department with Shield Security KSA. We take over all security operations, including guard management, supervisors, compliance, and reporting — at lower cost than internal teams.</p>"),
            ("What We Manage", "<ul><li>All guard deployment and scheduling</li><li>HR, payroll, and insurance</li><li>Training and certification</li><li>Nitaqat/Saudization compliance</li><li>Supervisor and manager layers</li><li>24/7 operations center oversight</li><li>Monthly reporting to client management</li></ul>"),
        ],
        "faqs": [
            ("Can I keep my existing guards and have you manage them?", "Yes. We offer a management overlay service where we manage your existing security workforce under our quality management system."),
        ],
        "related": [
            ("Manned Guarding Services", "manned-guarding/manned-guarding-services/index.html"),
            ("Security Manpower Supply", "manned-guarding/security-manpower-supply/index.html"),
        ]
    },
    "security-manpower-supply": {
        "title": "Security Manpower Supply Saudi Arabia",
        "desc": "Bulk security manpower supply for large operations, mega-projects, and industrial facilities across Saudi Arabia.",
        "tag": "Manpower Supply · KSA",
        "icon": "👥",
        "sections": [
            ("Security Manpower Supply", "<p>We supply trained security personnel at scale — from 10 guards to 1,000+ for large industrial, construction, and government contracts. All personnel are vetted, licensed, and ready to deploy.</p>"),
            ("Manpower Supply Capabilities", "<ul><li>Bulk guard supply (10–1,000+ personnel)</li><li>Supervisors and team leaders</li><li>Armed and unarmed officers</li><li>Female security officers</li><li>Control room operators</li><li>Security drivers and patrol officers</li></ul>"),
        ],
        "faqs": [
            ("How quickly can you supply large numbers of guards?", "For orders under 50 guards, we can mobilize within 1 week. For 50–500 guards, allow 2–4 weeks for vetting and induction."),
        ],
        "related": [
            ("Contract Security Guards", "manned-guarding/contract-security-guards/index.html"),
            ("NEOM Security Services", "construction-mega-project-security/neom-security-services/index.html"),
        ]
    },
}


PAGES = {}

# Helper to add pages
def add_pages(parent_slug, parent_title, parent_desc, parent_tag, parent_icon, children, parent_faqs, leaf_data):
    PAGES[parent_slug] = {
        "type": "parent",
        "title": parent_title,
        "desc": parent_desc,
        "tag": parent_tag,
        "icon": parent_icon,
        "children": children,
        "faqs": parent_faqs,
    }
    for child_slug, child_title, child_desc, child_icon in children:
        if parent_slug in leaf_data and child_slug in leaf_data[parent_slug]:
            d = leaf_data[parent_slug][child_slug]
        else:
            d = {
                "title": child_title + " in Riyadh",
                "desc": child_desc + " Professional, licensed, 24/7.",
                "tag": parent_title + " · Riyadh, KSA",
                "icon": child_icon,
                "sections": [
                    (child_title, f"<p>Shield Security KSA provides professional {child_title.lower()} across Riyadh and Saudi Arabia. Our team is Ministry of Interior licensed, trained to international standards, and available 24 hours a day.</p>"),
                    ("Our Approach", "<ul><li>Initial site assessment and consultation</li><li>Customized security plan</li><li>Deployment of vetted, licensed personnel</li><li>Regular supervision and quality checks</li><li>Monthly performance reporting</li></ul>"),
                    ("Why Choose Shield Security KSA", "<ul><li>Ministry of Interior licensed</li><li>Saudization compliant</li><li>HCIS certified (where applicable)</li><li>ISO 9001:2015 quality management</li><li>24/7 operations support</li><li>Competitive, transparent pricing</li></ul>"),
                ],
                "faqs": [
                    ("How do I get started?", "Contact us by phone, WhatsApp, or our quote form. We will arrange a free site assessment within 24 hours."),
                    ("Are you licensed to operate in Saudi Arabia?", "Yes. We hold a valid Ministry of Interior security company license and all our personnel are individually licensed."),
                ],
                "related": [
                    ("Security Guard Services", "manned-guarding/security-guard-services/index.html"),
                    ("Request a Quote", "informational/request-security-quote/index.html"),
                ]
            }
        PAGES[f"{parent_slug}/{child_slug}"] = {
            "type": "leaf",
            "parent_slug": parent_slug,
            "parent_title": parent_title,
            "child_slug": child_slug,
            **d
        }


# ─── MANNED GUARDING ─────────────────────────────────────────────────────────
add_pages("manned-guarding", "Manned Guarding Services", "Professional manned guarding services in Riyadh, Saudi Arabia. Licensed security guards for all sectors.", "Security Guarding · Riyadh, KSA", "🛡️", MG_CHILDREN, MG_FAQS, {"manned-guarding": MG_LEAF_PAGES})

# ─── PATROL RESPONSE ─────────────────────────────────────────────────────────
PRM_CHILDREN = [
    ("mobile-patrol-security","Mobile Patrol Security","Roving security patrols covering multiple sites in scheduled and random patterns.","🚗"),
    ("vehicle-patrol-security","Vehicle Patrol Security","Marked and unmarked vehicle patrols for deterrence and rapid response.","🚙"),
    ("rapid-response-security","Rapid Response Security","Emergency response units that reach your site within minutes of an alarm.","⚡"),
    ("emergency-response-security","Emergency Response Security","Trained teams for fire, intrusion, civil unrest, and crisis situations.","🚨"),
    ("alarm-monitoring-response","Alarm Monitoring & Response","24/7 alarm receiving center with live response to every activation.","🔔"),
    ("remote-cctv-monitoring","Remote CCTV Monitoring","Off-site live monitoring of your CCTV cameras with intervention capability.","📹"),
]
PRM_FAQS = [
    ("How fast is your rapid response?", "Our response vehicles are stationed strategically across Riyadh. Average response time is under 15 minutes within the city."),
    ("Do you monitor third-party alarm systems?", "Yes. We can integrate with most major alarm panel brands and assume monitoring responsibility."),
]
add_pages("patrol-response-monitoring","Patrol, Response & Monitoring","Mobile patrol, rapid response, and 24/7 monitoring services in Riyadh.","Patrol & Response · KSA","🚗",PRM_CHILDREN,PRM_FAQS,{})

# ─── EXECUTIVE PROTECTION ────────────────────────────────────────────────────
EP_CHILDREN = [
    ("executive-protection-services","Executive Protection Services","Close protection for C-suite executives, business leaders, and dignitaries.","🤵"),
    ("bodyguard-services","Bodyguard Services","Personal bodyguards for individuals and families in Saudi Arabia.","💪"),
    ("vip-protection-services","VIP Protection Services","Discreet, professional protection for VIPs visiting or residing in KSA.","⭐"),
    ("armed-escort-services","Armed Escort Services","Armed escorts for high-value cargo, cash, and VIP movements.","🔫"),
    ("royal-diplomatic-security","Royal & Diplomatic Security","Specialized security protocols for royal family staff and diplomatic missions.","👑"),
]
EP_FAQS = [
    ("Are your bodyguards armed?", "We provide both armed and unarmed close protection officers. Armed CPOs require additional MOI authorization, which we handle."),
    ("Can you provide female close protection officers?", "Yes. We have trained female CPOs available for female principals and mixed-gender protection details."),
]
add_pages("executive-protection","Executive Protection Services","VIP bodyguard and executive close protection services in Saudi Arabia.","Executive Protection · KSA","🤵",EP_CHILDREN,EP_FAQS,{})

# ─── ARMED/UNARMED ───────────────────────────────────────────────────────────
AU_CHILDREN = [
    ("armed-security-guard-services","Armed Security Guards","Licensed armed guards for high-risk environments, banks, and VIP protection.","🔫"),
    ("unarmed-security-guard-services","Unarmed Security Guards","Professional unarmed guards for standard commercial and residential sites.","🛡️"),
    ("specialized-protection","Specialized Protection","Elite security for critical infrastructure, data centers, and classified sites.","🏛️"),
    ("advanced-premium-security","Advanced Premium Security","Premium Tier 1 security packages combining guards, technology, and response.","💎"),
]
add_pages("armed-unarmed-security","Armed & Unarmed Security","Licensed armed and unarmed security guard services in Saudi Arabia.","Security Guards · KSA","🔫",AU_CHILDREN,[],{})

# ─── EVENTS ──────────────────────────────────────────────────────────────────
EV_CHILDREN = [
    ("event-security-services","Event Security Services","Full-service security management for private and public events.","🎪"),
    ("crowd-control-security","Crowd Control Security","Trained crowd management teams for large-scale public gatherings.","👥"),
    ("wedding-security-services","Wedding Security Services","Discreet security for weddings, receptions, and private celebrations.","💍"),
    ("corporate-event-security","Corporate Event Security","Security for conferences, product launches, and corporate functions.","🏢"),
    ("concert-festival-security","Concert & Festival Security","Large-scale event security for Riyadh Season, concerts, and festivals.","🎵"),
    ("vip-event-security","VIP Event Security","Exclusive security for high-profile private and VIP events.","⭐"),
]
EV_FAQS = [
    ("How far in advance should I book event security?", "For large events (500+ attendees), we recommend booking 4–6 weeks in advance. For smaller events, 1–2 weeks is usually sufficient."),
    ("Do you provide security for Riyadh Season events?", "Yes. We have extensive experience securing large-scale entertainment events in Riyadh, including crowd management and VIP protection."),
]
add_pages("event-security","Event Security Services","Professional event security in Riyadh. Crowd control, VIP protection, and full event security management.","Event Security · Riyadh","🎪",EV_CHILDREN,EV_FAQS,{})

# ─── FEMALE GUARDS ───────────────────────────────────────────────────────────
FG_CHILDREN = [
    ("female-security-guard-services","Female Security Guard Services","Trained female security officers for all environments in Saudi Arabia.","👩"),
    ("women-security-guards-saudi-arabia","Women Security Guards Saudi Arabia","Culturally sensitive female guard deployment across KSA sectors.","🇸🇦"),
]
add_pages("female-security-guards","Female Security Guards","Professional female security guards for malls, hospitals, events, and corporate sites in Saudi Arabia.","Female Security · KSA","👩",FG_CHILDREN,[],{})

# ─── RESIDENTIAL ─────────────────────────────────────────────────────────────
RS_CHILDREN = [
    ("residential-security-guards","Residential Security Guards","Guards for apartments, family homes, and residential areas.","🏠"),
    ("private-villa-security","Private Villa Security","Dedicated security teams for private villas in Riyadh and the Kingdom.","🏡"),
    ("gated-community-security","Gated Community Security","Access control and patrol for gated residential communities.","🔑"),
    ("residential-compound-guards","Residential Compound Guards","Security management for expat and diplomatic residential compounds.","🏘️"),
]
add_pages("residential-security","Residential Security Services","Private villa, compound, and residential security guards in Riyadh and Saudi Arabia.","Residential Security · KSA","🏠",RS_CHILDREN,[
    ("What is the minimum staffing for a villa?", "For a private villa, we typically deploy 1-2 guards on rotation. We assess your property and recommend the right level."),
],{})

# ─── COMMERCIAL ──────────────────────────────────────────────────────────────
CC_CHILDREN = [
    ("commercial-security-services","Commercial Security Services","Security solutions for offices, business parks, and commercial buildings.","🏢"),
    ("office-security-guards","Office Security Guards","Reception and floor security for corporate offices in Riyadh.","💼"),
    ("corporate-security-management","Corporate Security Management","Integrated security management for multi-site corporate operations.","📊"),
    ("security-services-for-businesses","Security Services for Businesses","Customized security for SMEs and large enterprises in Saudi Arabia.","🏪"),
    ("mall-security-guards","Mall Security Guards","Security guards and managers for shopping malls and retail centers.","🛒"),
]
add_pages("commercial-corporate-security","Commercial & Corporate Security","Office, mall, and corporate security guard services in Riyadh and across KSA.","Commercial Security · KSA","🏢",CC_CHILDREN,[],{})

# ─── RETAIL ──────────────────────────────────────────────────────────────────
RT_CHILDREN = [
    ("retail-security-guards","Retail Security Guards","Uniformed and plain-clothes guards for retail environments.","🛍️"),
    ("loss-prevention-services","Loss Prevention Services","Specialist loss prevention operatives reducing theft and shrinkage.","🔍"),
    ("jewelry-store-security","Jewelry Store Security","Armed and unarmed guards for jewelry stores and gold markets.","💎"),
    ("luxury-boutique-security","Luxury Boutique Security","Discreet, professional security for luxury brand stores in KSA.","👜"),
]
add_pages("retail-security","Retail Security Services","Retail security guards, loss prevention, and jewelry store protection in Saudi Arabia.","Retail Security · KSA","🛍️",RT_CHILDREN,[],{})

# ─── BANKING ─────────────────────────────────────────────────────────────────
BF_CHILDREN = [
    ("bank-security-guards","Bank Security Guards","Trained guards for bank branches, ATMs, and financial offices.","🏦"),
    ("financial-institution-guarding","Financial Institution Guarding","Security programs for investment firms, exchanges, and fintech companies.","💰"),
]
add_pages("banking-financial-security","Banking & Financial Security","Security guards for banks, ATMs, and financial institutions in Riyadh.","Banking Security · KSA","🏦",BF_CHILDREN,[],{})

# ─── HEALTHCARE ──────────────────────────────────────────────────────────────
HC_CHILDREN = [
    ("hospital-security-guards","Hospital Security Guards","Security for hospitals including A&E, pharmacy, and patient areas.","🏥"),
    ("clinic-security-services","Clinic Security Services","Guards and access control for medical clinics and specialist centers.","🩺"),
    ("pharmacy-guarding","Pharmacy Guarding","Armed and unarmed guards for pharmacies and drug distribution centers.","💊"),
]
add_pages("healthcare-security","Healthcare Security Services","Trained healthcare security guards for hospitals, clinics, and pharmacies in Saudi Arabia.","Healthcare Security · KSA","🏥",HC_CHILDREN,[],{})

# ─── EDUCATION ───────────────────────────────────────────────────────────────
ED_CHILDREN = [
    ("school-security-guards","School Security Guards","Child-safe trained guards for schools and educational facilities.","🎓"),
    ("university-campus-security","University Campus Security","Comprehensive security management for large university campuses.","🏫"),
    ("international-school-guarding","International School Guarding","Specialized security for international schools in Riyadh.","🌍"),
]
add_pages("education-security","Education Security Services","Security guards for schools, universities, and campuses in Saudi Arabia.","Education Security · KSA","🎓",ED_CHILDREN,[],{})

# ─── HOSPITALITY ─────────────────────────────────────────────────────────────
HT_CHILDREN = [
    ("hotel-security-guards","Hotel Security Guards","Security teams for 5-star hotels, resorts, and hospitality venues.","🏨"),
    ("resort-tourism-security","Resort & Tourism Security","Integrated security for tourist resorts and entertainment destinations.","🌴"),
    ("restaurant-venue-security","Restaurant & Venue Security","Doormen and security for restaurants, clubs, and entertainment venues.","🍽️"),
]
add_pages("hospitality-tourism-security","Hospitality & Tourism Security","Hotel, resort, and venue security guards in Riyadh and across Saudi Arabia.","Hospitality Security · KSA","🏨",HT_CHILDREN,[],{})

# ─── INDUSTRIAL ──────────────────────────────────────────────────────────────
IND_CHILDREN = [
    ("industrial-security-services","Industrial Security Services","Comprehensive security for industrial zones and manufacturing facilities.","🏭"),
    ("factory-security-guards","Factory Security Guards","Guards for factories including access control and production area patrols.","⚙️"),
    ("warehouse-security-guards","Warehouse Security Guards","Security for logistics centers, distribution hubs, and cold storage.","📦"),
    ("oil-gas-security-services","Oil & Gas Security Services","HCIS-compliant security for oil fields, refineries, and gas plants.","🛢️"),
    ("logistics-security","Logistics Security","Security for supply chain, fleet, and cargo operations.","🚚"),
    ("hcis-compliant-security","HCIS Compliant Security","Security services meeting HCIS requirements for critical infrastructure.","✅"),
]
IND_FAQS = [
    ("What is HCIS compliance?", "HCIS (High Commission for Industrial Security) is a Saudi body that regulates security at critical national infrastructure. We are approved to provide HCIS-compliant security services."),
    ("Do you provide security for ARAMCO contractors?", "Yes. We have experience providing security services for ARAMCO contractors and other major energy sector clients."),
]
add_pages("industrial-security","Industrial Security Services","HCIS-compliant industrial security for oil, gas, factories, and warehouses in Saudi Arabia.","Industrial Security · KSA","🏭",IND_CHILDREN,IND_FAQS,{})

# ─── CONSTRUCTION ────────────────────────────────────────────────────────────
CS_CHILDREN = [
    ("construction-site-security","Construction Site Security","Security for active construction sites, equipment, and workers.","🏗️"),
    ("neom-security-services","NEOM Security Services","Specialist security services for NEOM and related giga-project sites.","🌇"),
    ("qiddiya-project-security","Qiddiya Project Security","Security solutions for Qiddiya entertainment city development.","🎡"),
]
add_pages("construction-mega-project-security","Construction & Mega-Project Security","Security for NEOM, Qiddiya, construction sites, and Vision 2030 giga-projects in KSA.","Mega-Project Security · KSA","🏗️",CS_CHILDREN,[],{})

# ─── CIT ─────────────────────────────────────────────────────────────────────
CIT_CHILDREN = [
    ("cash-in-transit-cit-services","Cash-in-Transit (CIT) Services","Armored vehicle cash collection and delivery across Saudi Arabia.","💵"),
    ("secure-cash-transport","Secure Cash Transport","Secure transportation of cash for banks, retailers, and businesses.","🚐"),
    ("valuables-armored-transport","Valuables & Armored Transport","Armored transport for gold, jewelry, documents, and high-value goods.","🥇"),
    ("atm-security-services","ATM Security Services","ATM cash replenishment, maintenance escort, and protection services.","🏧"),
]
add_pages("cash-in-transit-security","Cash-in-Transit Security","Licensed armored cash-in-transit and valuables transport services across Saudi Arabia.","CIT Services · KSA","💵",CIT_CHILDREN,[
    ("Is CIT regulated in Saudi Arabia?", "Yes. Cash-in-transit is strictly regulated by SAMA (Saudi Central Bank) and the Ministry of Interior. All our CIT operations are fully licensed."),
],{})

# ─── AIRPORT / MARITIME ──────────────────────────────────────────────────────
AM_CHILDREN = [
    ("airport-security-services","Airport Security Services","Security solutions for airports, aviation facilities, and cargo zones.","✈️"),
    ("maritime-port-security","Maritime & Port Security","Port security, vessel protection, and maritime security management.","🚢"),
]
add_pages("airport-port-maritime-security","Airport, Port & Maritime Security","Security services for airports, seaports, and maritime facilities in Saudi Arabia.","Aviation & Maritime · KSA","✈️",AM_CHILDREN,[],{})

# ─── TECHNOLOGY ──────────────────────────────────────────────────────────────
TS_CHILDREN = [
    ("cctv-monitoring-services","CCTV Monitoring Services","Remote 24/7 CCTV monitoring with live intervention capability.","📹"),
    ("access-control-systems","Access Control Systems","Card, fob, and PIN access control systems for all facility types.","🔑"),
    ("biometric-security-systems","Biometric Security Systems","Fingerprint, facial recognition, and biometric entry systems.","👁️"),
    ("alarm-monitoring-services","Alarm Monitoring Services","24/7 alarm receiving center connected to your intruder alarms.","🔔"),
    ("security-system-installation","Security System Installation","Professional installation of all security technology systems.","🔧"),
    ("smart-security-solutions","Smart Security Solutions","AI-powered, integrated smart security for Vision 2030 era facilities.","🤖"),
]
add_pages("technology-security-systems","Security Technology Systems","CCTV, access control, biometric, and smart security system installation in Riyadh.","Security Technology · KSA","📹",TS_CHILDREN,[
    ("Do you install and monitor CCTV?", "Yes. We supply, install, and provide 24/7 remote monitoring of CCTV systems. We can also integrate with your existing camera infrastructure."),
],{})

# ─── DIPLOMATIC ──────────────────────────────────────────────────────────────
DG_CHILDREN = [
    ("ministry-interior-licensed-security","MOI Licensed Security","Our Ministry of Interior licensing credentials and compliance record.","🏛️"),
    ("embassy-consulate-security","Embassy & Consulate Security","Security services for embassies, consulates, and diplomatic missions.","🌐"),
    ("government-facility-security","Government Facility Security","Guards and security management for government buildings and offices.","🏛️"),
]
add_pages("diplomatic-government-security","Diplomatic & Government Security","MOI licensed security for embassies, government buildings, and diplomatic missions in Saudi Arabia.","Government Security · KSA","🏛️",DG_CHILDREN,[],{})

# ─── CONSULTING ──────────────────────────────────────────────────────────────
CR_CHILDREN = [
    ("security-risk-assessment","Security Risk Assessment","Comprehensive site security risk assessments with remediation plans.","📊"),
    ("security-audit-services","Security Audit Services","Independent security audits of your existing security measures.","🔍"),
    ("threat-assessment-services","Threat Assessment Services","Analysis of threat landscape facing your organization or facility.","⚠️"),
    ("security-consulting-services","Security Consulting Services","Expert security consultancy for design, planning, and operations.","💡"),
    ("safety-compliance-services","Safety & Compliance Services","Ensuring your security meets all Saudi regulatory requirements.","✅"),
    ("site-security-management","Site Security Management","Outsourced security management for complex, multi-zone sites.","🗺️"),
    ("field-supervision-inspection","Field Supervision & Inspection","On-site supervision and quality inspection of security operations.","🔎"),
]
add_pages("security-consulting-risk-management","Security Consulting & Risk Management","Security risk assessment, audits, threat analysis, and consulting services in Saudi Arabia.","Security Consulting · KSA","📊",CR_CHILDREN,[],{})


# ─── INFORMATIONAL PAGES ──────────────────────────────────────────────────────
INFO_PAGES = {
    "best-security-company-saudi-arabia": {
        "title": "Best Security Company in Saudi Arabia 2025",
        "desc": "Shield Security KSA — ranked among the best security companies in Saudi Arabia. Ministry of Interior licensed, ISO certified, serving 500+ clients.",
        "tag": "Best Security · Saudi Arabia 2025",
        "content": """
<div class="content-block fade-up">
<h2>Best Security Company in Saudi Arabia</h2>
<p>Choosing the right security company in Saudi Arabia is a critical decision. Here is what sets Shield Security KSA apart from the competition in 2025.</p>
<h3>What Makes a Security Company the Best?</h3>
<ul>
<li><strong>Ministry of Interior License:</strong> Legal requirement to operate. Shield is fully licensed.</li>
<li><strong>Guard Training Standards:</strong> Our guards undergo 80+ hours of initial training.</li>
<li><strong>Response Times:</strong> Average 15-minute emergency response in Riyadh.</li>
<li><strong>Saudization Compliance:</strong> We maintain all required Nitaqat ratios.</li>
<li><strong>HCIS Certification:</strong> Approved for critical infrastructure sites.</li>
<li><strong>Technology Integration:</strong> CCTV, access control, and reporting systems.</li>
<li><strong>Client Retention Rate:</strong> 94% annual client renewal rate.</li>
</ul>
</div>
<div class="content-block fade-up">
<h2>Why Clients Choose Shield Security KSA</h2>
<p>Over 500 organizations across Riyadh and Saudi Arabia trust Shield Security KSA with their security. Our clients include commercial banks, royal family residences, embassies, hospitals, shopping malls, and mega-project construction sites.</p>
<p>We are not a broker or staffing agency. We are an owner-operated security company with our own training facility, operations center, and field management team.</p>
</div>"""
    },
    "how-to-choose-security-company-ksa": {
        "title": "How to Choose a Security Company in Saudi Arabia",
        "desc": "Guide to selecting the right security company in Saudi Arabia. What to check, questions to ask, and red flags to avoid.",
        "tag": "Security Guide · Saudi Arabia",
        "content": """
<div class="content-block fade-up">
<h2>How to Choose the Right Security Company in Saudi Arabia</h2>
<p>With dozens of security companies operating in Riyadh and across Saudi Arabia, selecting the right partner requires careful evaluation. This guide covers what matters.</p>
<h3>Step 1: Verify the MOI License</h3>
<p>Every security company in Saudi Arabia must hold a valid Ministry of Interior license. Ask for the license number and verify it. An unlicensed company exposes you to legal liability.</p>
<h3>Step 2: Check Saudization (Nitaqat) Status</h3>
<p>Security companies must comply with Saudi national employment requirements. A company in violation of Nitaqat may face government sanctions that could interrupt your service.</p>
<h3>Step 3: Assess Guard Training</h3>
<p>Ask how many hours of training guards receive, what certifications they hold, and whether they complete refresher training. Minimum standard should be 40+ hours initial training.</p>
<h3>Step 4: Review Contract Terms</h3>
<p>Understand notice periods, liability clauses, KPI frameworks, and what happens if a guard underperforms. A professional company will have structured SLAs.</p>
<h3>Step 5: Check References</h3>
<p>Ask for 2–3 client references in your industry. A genuine, established security company will provide these without hesitation.</p>
</div>"""
    },
    "cost-of-hiring-security-guards-saudi-arabia": {
        "title": "Cost of Hiring Security Guards in Saudi Arabia 2025",
        "desc": "Guide to security guard pricing in Saudi Arabia. What factors affect cost and what to expect when budgeting.",
        "tag": "Pricing Guide · Saudi Arabia",
        "content": """
<div class="content-block fade-up">
<h2>Security Guard Costs in Saudi Arabia</h2>
<p>The cost of security guards in Saudi Arabia depends on several factors. This guide helps you understand what affects pricing and how to budget accurately.</p>
<h3>Key Pricing Factors</h3>
<ul>
<li><strong>Number of guards and shifts:</strong> 24/7 coverage requires shift rotation.</li>
<li><strong>Armed vs unarmed:</strong> Armed guards command 30–50% premium.</li>
<li><strong>Guard qualifications:</strong> Specialized roles (CPO, HCIS) cost more.</li>
<li><strong>Location:</strong> Remote sites outside Riyadh may incur transport costs.</li>
<li><strong>Contract duration:</strong> Annual contracts receive better rates.</li>
<li><strong>Technology integration:</strong> Adding CCTV monitoring increases monthly costs.</li>
</ul>
<h3>Typical Monthly Cost Ranges (SAR)</h3>
<ul>
<li>Single daytime guard (8-hour shift): SAR 3,000 – 5,000/month</li>
<li>24/7 static guard (3-guard rotation): SAR 10,000 – 16,000/month</li>
<li>Mobile patrol service (Riyadh city): SAR 4,000 – 8,000/month</li>
<li>Event security (per guard per day): SAR 300 – 600/day</li>
</ul>
<p><em>Note: Pricing is indicative. Contact us for an accurate quote for your specific requirements.</em></p>
</div>"""
    },
    "request-security-quote": {
        "title": "Request a Security Quote — Riyadh, Saudi Arabia",
        "desc": "Get a free security quote from Shield Security KSA. Response within 2 hours. Ministry of Interior licensed security services.",
        "tag": "Free Quote · Riyadh, KSA",
        "content": """
<div class="content-block fade-up">
<h2>Get Your Free Security Quote</h2>
<p>Complete the form and our team will contact you within 2 hours with a tailored proposal. For urgent requirements, please call us directly.</p>
<form id="lead-form">
  <div class="form-row">
    <div class="form-group">
      <label>Full Name *</label>
      <input type="text" name="name" required placeholder="Your full name">
    </div>
    <div class="form-group">
      <label>Company Name</label>
      <input type="text" name="company" placeholder="Your company (if applicable)">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group">
      <label>Phone Number *</label>
      <input type="tel" name="phone" required placeholder="+966 5X XXX XXXX">
    </div>
    <div class="form-group">
      <label>Email Address</label>
      <input type="email" name="email" placeholder="your@email.com">
    </div>
  </div>
  <div class="form-group">
    <label>Type of Security Required *</label>
    <select name="service" required>
      <option value="">-- Select Service --</option>
      <option>Manned Security Guards</option>
      <option>Mobile Patrol</option>
      <option>Executive / VIP Protection</option>
      <option>Event Security</option>
      <option>CCTV & Technology</option>
      <option>Cash-in-Transit</option>
      <option>Security Consulting</option>
      <option>Other</option>
    </select>
  </div>
  <div class="form-group">
    <label>Site Location (City / District)</label>
    <input type="text" name="location" placeholder="e.g. Al Olaya, Riyadh">
  </div>
  <div class="form-group">
    <label>Additional Details</label>
    <textarea name="message" placeholder="Describe your security requirements, number of guards needed, hours of coverage, etc."></textarea>
  </div>
  <button type="submit" class="btn btn-gold btn-lg">Submit Request →</button>
</form>
</div>
<div class="content-block fade-up">
<h3>What Happens Next?</h3>
<ul>
<li>We contact you within 2 hours (business hours) or next morning</li>
<li>We arrange a free site visit at your convenience</li>
<li>We provide a detailed written proposal within 48 hours</li>
<li>No obligation — no hard sell</li>
</ul>
</div>"""
    },
    "security-guard-jobs-ksa": {
        "title": "Security Guard Jobs in Saudi Arabia — Join Shield Security KSA",
        "desc": "Security guard vacancies in Saudi Arabia. Join Shield Security KSA. Licensed, professional, competitive pay.",
        "tag": "Careers · Saudi Arabia",
        "content": """
<div class="content-block fade-up">
<h2>Security Guard Jobs at Shield Security KSA</h2>
<p>We are always hiring trained, motivated security professionals to join our growing team in Riyadh and across Saudi Arabia.</p>
<h3>Current Vacancies</h3>
<ul>
<li>Security Guards (armed and unarmed)</li>
<li>Shift Supervisors</li>
<li>Control Room Operators</li>
<li>Female Security Officers</li>
<li>Close Protection Officers (CPO)</li>
<li>Mobile Patrol Officers</li>
</ul>
<h3>Requirements</h3>
<ul>
<li>Valid Saudi MOI security license (or eligible for licensing)</li>
<li>Clean background record</li>
<li>Saudi national preferred (Nitaqat compliant roles)</li>
<li>Good physical fitness</li>
<li>Fluent Arabic; English an advantage</li>
</ul>
<h3>How to Apply</h3>
<p>Send your CV and copies of any existing security certifications to <a href="mailto:careers@shieldsecurityksa.com">careers@shieldsecurityksa.com</a> or WhatsApp us at {WA_LINK}.</p>
</div>""".format(WA_LINK=WA_LINK)
    },
    "best-security-company-saudi-arabia": {
        "title": "Best Security Company in Saudi Arabia 2025",
        "desc": "Shield Security KSA — ranked among the best security companies in Saudi Arabia. MOI licensed, ISO certified.",
        "tag": "Best Security · KSA 2025",
        "content": """<div class="content-block fade-up">
<h2>Best Security Company in Saudi Arabia 2025</h2>
<p>Shield Security KSA is a Ministry of Interior licensed security provider serving 500+ clients across Riyadh and the Kingdom. Here is what sets us apart.</p>
<h3>Our Credentials</h3>
<ul>
<li>Ministry of Interior Security License (Active)</li>
<li>HCIS Certified for Critical Infrastructure</li>
<li>ISO 9001:2015 Quality Management</li>
<li>Nitaqat Platinum Saudization status</li>
<li>15+ years operating in Saudi Arabia</li>
</ul>
</div>"""
    },
    "security-company-phone-numbers-riyadh": {
        "title": "Security Company Phone Numbers Riyadh",
        "desc": "Contact Shield Security KSA in Riyadh. 24/7 security company phone number, WhatsApp, and emergency line.",
        "tag": "Contact · Riyadh, KSA",
        "content": f"""<div class="content-block fade-up">
<h2>Shield Security KSA — Contact Numbers Riyadh</h2>
<div class="contact-grid" style="margin-top:1.5rem">
  <div>
    <div class="contact-detail"><span class="icon">📞</span><div><strong>Main Office (24/7)</strong><p>{COMPANY_PHONE}</p></div></div>
    <div class="contact-detail"><span class="icon">💬</span><div><strong>WhatsApp</strong><p><a href="{WA_LINK}" target="_blank">Message Us on WhatsApp</a></p></div></div>
    <div class="contact-detail"><span class="icon">📧</span><div><strong>Email</strong><p><a href="mailto:{COMPANY_EMAIL}">{COMPANY_EMAIL}</a></p></div></div>
    <div class="contact-detail"><span class="icon">📍</span><div><strong>Address</strong><p>{COMPANY_ADDRESS}</p></div></div>
    <div class="contact-detail"><span class="icon">🕐</span><div><strong>Operating Hours</strong><p>24 hours / 7 days / 365 days</p></div></div>
  </div>
</div>
</div>"""
    },
    "security-guard-duties-responsibilities": {
        "title": "Security Guard Duties & Responsibilities in Saudi Arabia",
        "desc": "Complete guide to security guard duties, responsibilities, and legal authority in Saudi Arabia.",
        "tag": "Security Guide · Saudi Arabia",
        "content": """<div class="content-block fade-up">
<h2>Security Guard Duties and Responsibilities</h2>
<p>Understanding the role of a security guard in Saudi Arabia helps clients set expectations and guards understand their obligations.</p>
<h3>Core Duties</h3>
<ul>
<li>Access control — checking credentials of all site visitors</li>
<li>Perimeter patrol — walking or driving the site boundary</li>
<li>Incident response — managing and reporting security incidents</li>
<li>CCTV monitoring — watching live or recorded camera feeds</li>
<li>Report writing — maintaining daily occurrence logs</li>
<li>Emergency liaison — working with police, fire, and ambulance</li>
<li>Customer service — directing visitors and assisting staff</li>
</ul>
<h3>Legal Authority in Saudi Arabia</h3>
<p>Saudi security guards have no powers of arrest beyond citizen's arrest. They cannot carry firearms without a specific MOI armed guard license. Their authority is limited to controlling access to private property and detaining suspects for handover to police.</p>
</div>"""
    },
    "security-guard-contract-prices": {
        "title": "Security Guard Contract Prices Saudi Arabia",
        "desc": "Security guard contract pricing in Saudi Arabia. Monthly rates, annual contracts, and what affects cost.",
        "tag": "Pricing · Saudi Arabia",
        "content": """<div class="content-block fade-up">
<h2>Security Guard Contract Prices in Saudi Arabia</h2>
<p>Security guard contract pricing in Saudi Arabia is influenced by shift length, guard grade, location, and contract duration. Below are indicative monthly contract rates.</p>
<h3>Pricing Overview (SAR/Month)</h3>
<ul>
<li>Day-only guard (8-hour): SAR 3,000–5,000</li>
<li>24/7 single post (3-guard rotation): SAR 10,000–16,000</li>
<li>Armed guard (daily rate): SAR 250–450/shift</li>
<li>Supervisory layer: +15–20% on guard cost</li>
<li>Technology (CCTV + monitoring): SAR 2,000–5,000/month</li>
</ul>
<p>Annual contracts receive a 5–10% discount vs monthly rolling arrangements. Contact us for a precise quote.</p>
</div>"""
    },
}

COMPETITORS = {
    "amnco-security-alternatives": {
        "title": "AMNCO Security Alternatives — Shield Security KSA",
        "desc": "Looking for AMNCO Security alternatives in Saudi Arabia? Shield Security KSA offers comparable services at competitive rates.",
        "content": """<div class="content-block fade-up">
<h2>AMNCO Security Alternatives in Saudi Arabia</h2>
<p>If you are evaluating alternatives to AMNCO for security services in Saudi Arabia, Shield Security KSA is a highly qualified option. We offer the same range of services — manned guarding, patrol, CIT, and technology — with a client-first approach and competitive pricing.</p>
<h3>Why Consider Shield Security KSA?</h3>
<ul>
<li>Ministry of Interior licensed — same regulatory standing</li>
<li>15+ years experience in the Saudi market</li>
<li>Dedicated account managers (not call centers)</li>
<li>Flexible contract terms</li>
<li>Faster response times in Riyadh region</li>
</ul>
<p><em>Note: We respect all competitors in the Saudi security market. This page is for informational comparison purposes only.</em></p>
</div>"""
    },
    "aman-aman-security-review": {
        "title": "Aman Security Review & Comparison — Shield Security KSA",
        "desc": "Independent review and comparison of Aman security services vs Shield Security KSA in Saudi Arabia.",
        "content": """<div class="content-block fade-up">
<h2>Aman Security — Review & Alternative</h2>
<p>Aman is one of the established security companies in Saudi Arabia. If you are comparing providers, here is how Shield Security KSA positions against the market standard.</p>
<h3>Service Comparison</h3>
<ul>
<li>Both companies hold MOI licenses</li>
<li>Shield offers more flexible contract terms for SMEs</li>
<li>Shield has dedicated rapid response units in Riyadh</li>
<li>Shield provides NEOM and giga-project security capability</li>
</ul>
<p><em>Note: This comparison is for informational purposes. We encourage clients to evaluate all licensed providers.</em></p>
</div>"""
    },
    "arkanat-security-comparison": {
        "title": "Arkanat Security Comparison — Shield Security KSA",
        "desc": "Compare Arkanat security services with Shield Security KSA. Find the right licensed security provider for your needs in Saudi Arabia.",
        "content": """<div class="content-block fade-up">
<h2>Arkanat Security vs Shield Security KSA</h2>
<p>If you are comparing Arkanat with other Saudi security providers, this overview helps you understand Shield Security KSA's offering and where we differ.</p>
<h3>Shield Security KSA Differentiators</h3>
<ul>
<li>Direct owner-operator model (no subcontracting)</li>
<li>In-house training academy</li>
<li>Technology-integrated security programs</li>
<li>Bilingual (Arabic/English) management and guards</li>
<li>Transparent SLA-based contracts</li>
</ul>
</div>"""
    },
    "best-security-companies-comparison-ksa": {
        "title": "Best Security Companies in Saudi Arabia — 2025 Comparison",
        "desc": "Independent comparison of the top security companies in Saudi Arabia in 2025. MOI licensed providers reviewed.",
        "content": """<div class="content-block fade-up">
<h2>Best Security Companies in Saudi Arabia 2025</h2>
<p>Saudi Arabia's security industry is regulated by the Ministry of Interior, ensuring all licensed companies meet baseline standards. Here is what differentiates the top players.</p>
<h3>What to Compare</h3>
<ul>
<li><strong>MOI License validity</strong> — all top companies must have this</li>
<li><strong>HCIS certification</strong> — needed for oil, gas, and critical sites</li>
<li><strong>Saudization rate</strong> — Platinum status = best compliance</li>
<li><strong>Response time guarantees</strong> — ask for SLA commitments</li>
<li><strong>Technology capability</strong> — CCTV, access control, reporting apps</li>
<li><strong>Sector experience</strong> — do they have references in your industry?</li>
</ul>
<h3>Why Shield Security KSA Stands Out</h3>
<p>We combine the capabilities of a large security company with the responsiveness of a specialist provider. Our clients include embassies, hospitals, banks, retailers, and mega-project operators.</p>
</div>"""
    }
}


# ─── WRITE PAGES ──────────────────────────────────────────────────────────────

def write(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"  ✓ {path.replace(BASE+'/', '')}")

print("\n=== Building Shield Security KSA ===\n")

# Homepage
write(f"{BASE}/index.html", build_homepage())

# Service pages
for key, page in PAGES.items():
    if page["type"] == "parent":
        slug = key
        html = build_parent_page(
            slug, page["title"], page["desc"], page["tag"], page["icon"],
            page["children"], page.get("faqs", [])
        )
        write(f"{BASE}/{slug}/index.html", html)
    elif page["type"] == "leaf":
        parent_slug = page["parent_slug"]
        child_slug = page["child_slug"]
        sections = page.get("sections", [])
        faqs = page.get("faqs", [])
        related = page.get("related", [])
        html = build_leaf_page(
            parent_slug, page["parent_title"],
            child_slug, page["title"], page["desc"], page["tag"], page["icon"],
            sections, faqs, related
        )
        write(f"{BASE}/{parent_slug}/{child_slug}/index.html", html)

# Informational pages
for slug, data in INFO_PAGES.items():
    depth = 2
    p = "../../"
    bc = [("Home","index.html"),("Resources",None),(data["title"],None)]
    bc_html = ""
    for label, url in bc:
        if url:
            bc_html += f'<a href="{p}{url}">{label}</a><span class="sep">›</span>'
        else:
            bc_html += f'<span>{label}</span>'
    badges = '<span class="badge badge-gold">MOI Licensed</span>&nbsp;<span class="badge badge-green">Free Guide</span>'

    html = header(data["title"], data["desc"], f"/informational/{slug}/", depth=depth)
    html += CERT_BAR
    html += f"""
<section class="page-hero">
  <div class="container">
    <nav class="breadcrumb">{bc_html}</nav>
    <span class="page-hero-tag">{data["tag"]}</span>
    <h1>{data["title"]}</h1>
    <p class="page-hero-desc">{data["desc"]}</p>
    {badges}
    <div class="hero-actions mt-3">
      <a href="{p}informational/request-security-quote/index.html" class="btn btn-gold btn-lg">Get Free Quote</a>
      <a href="tel:{COMPANY_PHONE}" class="btn btn-ghost btn-lg">📞 {COMPANY_PHONE}</a>
    </div>
  </div>
</section>
<section class="section">
  <div class="container">
    {data["content"]}
  </div>
</section>"""
    html += cta_section(prefix=p)
    html += footer(prefix=p)
    write(f"{BASE}/informational/{slug}/index.html", html)

# Competitor pages
for slug, data in COMPETITORS.items():
    depth = 2
    p = "../../"
    bc = [("Home","index.html"),("Comparisons",None),(data["title"],None)]
    bc_html = ""
    for label, url in bc:
        if url:
            bc_html += f'<a href="{p}{url}">{label}</a><span class="sep">›</span>'
        else:
            bc_html += f'<span>{label}</span>'

    html = header(data["title"], data["desc"], f"/competitors/{slug}/", depth=depth)
    html += CERT_BAR
    html += f"""
<section class="page-hero">
  <div class="container">
    <nav class="breadcrumb">{bc_html}</nav>
    <h1>{data["title"]}</h1>
    <p class="page-hero-desc">{data["desc"]}</p>
    <div class="hero-actions mt-3">
      <a href="{p}informational/request-security-quote/index.html" class="btn btn-gold btn-lg">Get Free Quote</a>
      <a href="tel:{COMPANY_PHONE}" class="btn btn-ghost btn-lg">📞 {COMPANY_PHONE}</a>
    </div>
  </div>
</section>
<section class="section">
  <div class="container">
    {data["content"]}
  </div>
</section>"""
    html += cta_section(prefix=p)
    html += footer(prefix=p)
    write(f"{BASE}/competitors/{slug}/index.html", html)

print(f"\n✅ Done! All pages generated.\n")

# Count pages
import glob
pages = glob.glob(f"{BASE}/**/*.html", recursive=True)
print(f"Total HTML files: {len(pages)}")
