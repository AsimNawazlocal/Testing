# Shield Security KSA — Rank & Rent Lead Gen Site
## Riyadh, Saudi Arabia | Security Services Niche

---

## 📁 Site Structure

```
shield-ksa/
├── index.html                    # Homepage
├── sitemap.xml                   # XML Sitemap (118 URLs)
├── robots.txt
├── _redirects                    # Cloudflare Pages redirects
├── _headers                      # Cloudflare Pages security headers
├── assets/
│   ├── css/main.css              # Global styles
│   └── js/main.js                # Interactive JS
├── manned-guarding/              # Parent + 7 leaf pages
├── patrol-response-monitoring/   # Parent + 6 leaf pages
├── executive-protection/         # Parent + 5 leaf pages
├── armed-unarmed-security/       # Parent + 4 leaf pages
├── event-security/               # Parent + 6 leaf pages
├── female-security-guards/       # Parent + 2 leaf pages
├── residential-security/         # Parent + 4 leaf pages
├── commercial-corporate-security/# Parent + 5 leaf pages
├── retail-security/              # Parent + 4 leaf pages
├── banking-financial-security/   # Parent + 2 leaf pages
├── healthcare-security/          # Parent + 3 leaf pages
├── education-security/           # Parent + 3 leaf pages
├── hospitality-tourism-security/ # Parent + 3 leaf pages
├── industrial-security/          # Parent + 6 leaf pages
├── construction-mega-project-security/ # Parent + 3 leaf pages
├── cash-in-transit-security/     # Parent + 4 leaf pages
├── airport-port-maritime-security/     # Parent + 2 leaf pages
├── technology-security-systems/  # Parent + 6 leaf pages
├── diplomatic-government-security/     # Parent + 3 leaf pages
├── security-consulting-risk-management/ # Parent + 7 leaf pages
├── informational/                # 8 informational/resource pages
└── competitors/                  # 4 comparison pages
```

**Total: 118 HTML pages**

---

## 🚀 Deploying to Cloudflare Pages

### Method 1: Direct Upload (Fastest)

1. Go to [dash.cloudflare.com](https://dash.cloudflare.com)
2. Click **Workers & Pages** → **Create Application** → **Pages** → **Direct Upload**
3. Name your project: `shield-security-ksa`
4. Drag and drop the entire `shield-ksa/` folder
5. Click **Deploy**
6. Your site is live at `shield-security-ksa.pages.dev`

### Method 2: GitHub + Cloudflare Pages (Recommended for updates)

1. Create a new GitHub repo (private)
2. Push the `shield-ksa/` directory contents to the repo root
3. In Cloudflare Dashboard → Pages → Create Application → Connect to Git
4. Select your repo
5. **Build Settings:** Leave blank (static site, no build command needed)
6. **Build output directory:** `/` (root)
7. Deploy

---

## ⚙️ Customization Checklist

Before going live, update these placeholders:

### 1. Company Details (`build.py` variables at top, or find-replace in HTML)
- [ ] `+966 50 000 0000` → Your actual phone number
- [ ] `info@shieldsecurityksa.com` → Your email
- [ ] `https://wa.me/966500000000` → Your WhatsApp link
- [ ] `King Fahad Road, Al Olaya, Riyadh 12214` → Your address
- [ ] MOI License number → Your real license number

### 2. Domain
- [ ] Update all canonical URLs from `shieldsecurityksa.com` to your domain
- [ ] Update `sitemap.xml` domain
- [ ] Quickest way: Find-replace `shieldsecurityksa.com` in all files

### 3. Lead Form
The contact form in `informational/request-security-quote/index.html` currently shows a success message on submit (no backend). To capture leads:
- **Option A: Formspree** — Add `action="https://formspree.io/f/YOUR_ID"` to the form tag and remove the JS intercept
- **Option B: Netlify Forms** — Add `netlify` attribute to form (if using Netlify instead)
- **Option C: Cloudflare Workers** — Build a Worker to email leads

### 4. Analytics
Add before `</head>` in each page (or rebuild with `build.py`):
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

### 5. Google Search Console
- Upload `sitemap.xml` URL to GSC after deployment

---

## 🔄 Regenerating Pages

If you want to modify content, edit `build.py` and re-run:

```bash
python3 build.py
```

Key sections to edit in `build.py`:
- `COMPANY_NAME`, `COMPANY_PHONE`, etc. — company details
- `MG_LEAF_PAGES` — Manned Guarding detailed content
- `INFO_PAGES` — Informational page content
- `COMPETITORS` — Competitor comparison content
- `add_pages(...)` calls — Add services or change descriptions

---

## 🎨 Design System

**Colors:**
- Navy: `#0a1628`
- Gold: `#c9a84c`
- Obsidian: `#06101e`

**Fonts (Google Fonts):**
- Display: Bebas Neue
- Serif accent: Cormorant Garamond
- Body: DM Sans

**All in:** `assets/css/main.css`

---

## 📈 SEO Notes

- All pages have unique `<title>` and `<meta description>`
- Canonical URLs set on every page
- JSON-LD schema markup on every page
- XML Sitemap with 118 URLs
- `robots.txt` configured
- Clean URL structure matching your provided sitemap
- Mobile responsive
- Fast-loading (pure HTML/CSS/JS, no frameworks)

---

## 📞 Lead Capture Points

Every page has:
1. Header "Get Quote" button → `/informational/request-security-quote/`
2. Footer phone number (click-to-call)
3. Floating WhatsApp button (fixed bottom-right)
4. CTA banner section on every page
5. Sidebar quote form on all leaf pages

---

*Generated with Shield Security KSA Site Builder | Rank & Rent Model*
